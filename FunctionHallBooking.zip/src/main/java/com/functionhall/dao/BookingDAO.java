package com.functionhall.dao;

import com.functionhall.model.Booking;
import com.functionhall.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BookingDAO {

    private static final String INSERT_SQL =
        "INSERT INTO bookings " +
        "(customer_name, phone, email, event_type, event_date, guests, " +
        "decoration, food_service, food_items, hall_name, special_request) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    public boolean saveBooking(Booking booking) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(INSERT_SQL)) {

            ps.setString(1, booking.getCustomerName());
            ps.setString(2, booking.getPhone());
            ps.setString(3, booking.getEmail());
            ps.setString(4, booking.getEventType());
            ps.setDate(5, java.sql.Date.valueOf(booking.getEventDate()));
            ps.setInt(6, booking.getGuests());
            ps.setString(7, booking.getDecoration());
            ps.setString(8, booking.getFoodService());
            ps.setString(9, booking.getFoodItems());
            ps.setString(10, booking.getHallName());
            ps.setString(11, booking.getSpecialRequest());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
