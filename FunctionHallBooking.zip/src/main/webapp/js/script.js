function toggleFood(show) {
    const box = document.getElementById("foodBox");
    const checkboxes = box.querySelectorAll('input[type="checkbox"]');

    box.style.display = show ? "block" : "none";

    checkboxes.forEach(cb => {
        cb.disabled = !show;
        if (!show) cb.checked = false;
    });
}

function validateForm() {
    const dateInput = document.getElementById("eventDate");
    const selectedDate = new Date(dateInput.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (selectedDate < today) {
        alert("Please select today or a future event date.");
        return false;
    }

    const foodService = document.querySelector('input[name="foodService"]:checked').value;
    if (foodService === "With Food") {
        const selectedFood = document.querySelectorAll(
            '#foodBox input[type="checkbox"]:checked'
        );

        if (selectedFood.length === 0) {
            alert("Please select at least one food item.");
            return false;
        }
    }

    return true;
}

document.addEventListener("DOMContentLoaded", () => {
    const dateInput = document.getElementById("eventDate");
    const today = new Date().toISOString().split("T")[0];
    dateInput.min = today;
    toggleFood(true);
});
