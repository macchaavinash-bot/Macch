CREATE DATABASE IF NOT EXISTS function_hall_db;
USE function_hall_db;

CREATE TABLE IF NOT EXISTS bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(120),
    event_type VARCHAR(50) NOT NULL,
    event_date DATE NOT NULL,
    guests INT NOT NULL,
    decoration VARCHAR(30) NOT NULL,
    food_service VARCHAR(30) NOT NULL,
    food_items TEXT,
    hall_name VARCHAR(100) NOT NULL,
    special_request VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample data (optional)
INSERT INTO bookings
(customer_name, phone, email, event_type, event_date, guests, decoration, food_service, food_items, hall_name, special_request)
VALUES
('Demo Customer', '9876543210', 'demo@example.com', 'Wedding', '2027-01-15', 300,
 'With Decoration', 'With Food',
 'Veg Biryani, Paneer Butter Masala, Gulab Jamun, Ice Cream',
 'Royal Grand Hall', 'Stage flowers and welcome board');
